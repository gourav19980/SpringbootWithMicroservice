package com.example.auth.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "users")
public class User {
    @Id
    private String mailId;
    private String password;
    private String role; // employer or jobseeker

    // Getters and Setters
}