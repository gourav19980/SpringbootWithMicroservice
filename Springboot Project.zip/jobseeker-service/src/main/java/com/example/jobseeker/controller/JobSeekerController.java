package com.example.jobseeker.controller;

import org.springframework.web.bind.annotation.*;
import com.example.jobseeker.model.JobSeeker;
import com.example.jobseeker.repository.JobSeekerRepository;

import java.util.Optional;

@RestController
@RequestMapping("/jobseekers")
public class JobSeekerController {

    private final JobSeekerRepository repository;

    public JobSeekerController(JobSeekerRepository repository) {
        this.repository = repository;
    }

    @PostMapping("/register")
    public JobSeeker register(@RequestBody JobSeeker jobSeeker) {
        return repository.save(jobSeeker);
    }

    @GetMapping("/view/{userId}")
    public Optional<JobSeeker> getProfile(@PathVariable String userId) {
        return repository.findById(userId);
    }
}