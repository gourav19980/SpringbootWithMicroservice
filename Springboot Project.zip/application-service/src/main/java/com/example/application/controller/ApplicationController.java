package com.example.application.controller;

import org.springframework.web.bind.annotation.*;
import com.example.application.model.JobApplication;
import com.example.application.repository.JobApplicationRepository;

import java.util.List;

@RestController
@RequestMapping("/applications")
public class ApplicationController {

    private final JobApplicationRepository repository;

    public ApplicationController(JobApplicationRepository repository) {
        this.repository = repository;
    }

    @PostMapping("/apply")
    public JobApplication apply(@RequestBody JobApplication application) {
        return repository.save(application);
    }

    @GetMapping("/view/{jobSeekerId}")
    public List<JobApplication> getApplications(@PathVariable String jobSeekerId) {
        return repository.findByJobSeekerId(jobSeekerId);
    }

    @PutMapping("/updateStatus/{id}/{status}")
    public String updateStatus(@PathVariable String id, @PathVariable String status) {
        var application = repository.findById(id);
        if (application.isPresent()) {
            application.get().setStatusApply(status);
            repository.save(application.get());
            return "Status updated";
        }
        return "Application not found";
    }
}