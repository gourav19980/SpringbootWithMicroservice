package com.example.jobopening.controller;

import org.springframework.web.bind.annotation.*;
import com.example.jobopening.model.JobOpening;
import com.example.jobopening.repository.JobOpeningRepository;

import java.util.List;

@RestController
@RequestMapping("/jobs")
public class JobOpeningController {

    private final JobOpeningRepository repository;

    public JobOpeningController(JobOpeningRepository repository) {
        this.repository = repository;
    }

    @PostMapping("/post")
    public JobOpening postJob(@RequestBody JobOpening jobOpening) {
        return repository.save(jobOpening);
    }

    @GetMapping("/viewbycompany/{companyId}")
    public List<JobOpening> getJobsByCompany(@PathVariable String companyId) {
        return repository.findByCompanyId(companyId);
    }

    @GetMapping("/viewbyrole/{position}")
    public List<JobOpening> getJobsByRole(@PathVariable String position) {
        return repository.findByPosition(position);
    }
}