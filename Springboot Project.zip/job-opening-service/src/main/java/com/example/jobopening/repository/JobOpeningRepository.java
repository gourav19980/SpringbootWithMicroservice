package com.example.jobopening.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.example.jobopening.model.JobOpening;

import java.util.List;

public interface JobOpeningRepository extends MongoRepository<JobOpening, String> {
    List<JobOpening> findByCompanyId(String companyId);
    List<JobOpening> findByPosition(String position);
}