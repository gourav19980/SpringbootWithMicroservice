package com.example.employer.controller;

import org.springframework.web.bind.annotation.*;
import com.example.employer.model.Employer;
import com.example.employer.repository.EmployerRepository;

import java.util.List;

@RestController
@RequestMapping("/employers")
public class EmployerController {

    private final EmployerRepository repository;

    public EmployerController(EmployerRepository repository) {
        this.repository = repository;
    }

    @PostMapping("/register")
    public Employer register(@RequestBody Employer employer) {
        return repository.save(employer);
    }

    @GetMapping("/all")
    public List<Employer> getAllEmployers() {
        return repository.findAll();
    }
}