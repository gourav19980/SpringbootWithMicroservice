package com.example.employer.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.example.employer.model.Employer;

public interface EmployerRepository extends MongoRepository<Employer, String> {
}