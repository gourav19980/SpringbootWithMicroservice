package com.example.employer.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "employers")
public class Employer {
    @Id
    private String companyId;
    private String companyName;
    private String registeredEmail;
    private String phone;
    private String address;

    // Getters and Setters
}