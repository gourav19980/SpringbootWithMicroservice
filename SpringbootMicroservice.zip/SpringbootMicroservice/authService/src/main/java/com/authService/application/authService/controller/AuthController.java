package com.authService.application.authService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.authService.application.authService.service.AuthService;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public String login(@RequestParam String mailId, @RequestParam String password) {
        return authService.login(mailId, password);
    }

    @PostMapping("/logout")
    public String logout(@RequestParam String mailId) {
        return authService.logout(mailId);
    }
}
