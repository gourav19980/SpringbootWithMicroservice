package com.authService.application.authService.service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.authService.application.authService.model.User;
import com.authService.application.authService.repository.UserRepository;

@Service
public class AuthService {
    @Autowired
    private UserRepository userRepository;
    private Set<String> activeSessions = new HashSet<>();

    public String login(String mailId, String password) {
        Optional<User> userOpt = userRepository.findByMailId(mailId);
        if (userOpt.isPresent() && userOpt.get().getPassword().equals(password)) {
            activeSessions.add(mailId);
            return "Login successful! Role: " + userOpt.get().getRole();
        }
        return "Invalid credentials";
    }

    public String logout(String mailId) {
        if (activeSessions.remove(mailId)) {
            return "Logout successful";
        }
        return "User not logged in";
    }
}
