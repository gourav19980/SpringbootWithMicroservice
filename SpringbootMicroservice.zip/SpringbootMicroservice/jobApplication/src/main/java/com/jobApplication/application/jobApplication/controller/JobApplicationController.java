package com.jobApplication.application.jobApplication.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jobApplication.application.jobApplication.constants.ApplicationStatus;
import com.jobApplication.application.jobApplication.model.JobApplication;
import com.jobApplication.application.jobApplication.service.JobApplicationService;

@RestController
@RequestMapping("/application")
public class JobApplicationController {
    @Autowired
    private JobApplicationService jobApplicationService;

    @PostMapping("/apply")
    public JobApplication apply(@RequestBody JobApplication jobApplication) {
        return jobApplicationService.applyForJob(jobApplication);
    }

    @GetMapping("/view/{applicationId}")
    public Optional<JobApplication> viewApplication(@PathVariable Long applicationId) {
        return jobApplicationService.getApplicationById(applicationId);
    }

    @PutMapping("/updateStatus/{applicationId}")
    public JobApplication updateStatus(@PathVariable Long applicationId, @RequestParam ApplicationStatus status, @RequestParam String role) {
        if (!"EMPLOYER".equalsIgnoreCase(role)) {
            throw new RuntimeException("Only employer role can update application status");
        }
        return jobApplicationService.updateApplicationStatus(applicationId, status);
    }
}
