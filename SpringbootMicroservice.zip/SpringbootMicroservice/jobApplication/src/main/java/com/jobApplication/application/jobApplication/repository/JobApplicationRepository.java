package com.jobApplication.application.jobApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jobApplication.application.jobApplication.model.JobApplication;

public interface JobApplicationRepository extends JpaRepository<JobApplication, Long> {}