package com.jobApplication.application.jobApplication.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobApplication.application.jobApplication.constants.ApplicationStatus;
import com.jobApplication.application.jobApplication.model.JobApplication;
import com.jobApplication.application.jobApplication.repository.JobApplicationRepository;

@Service
public class JobApplicationService {
    @Autowired
    private JobApplicationRepository jobApplicationRepository;

    public JobApplication applyForJob(JobApplication jobApplication) {
        jobApplication.setStatusApply(ApplicationStatus.PENDING);
        return jobApplicationRepository.save(jobApplication);
    }

    public Optional<JobApplication> getApplicationById(Long applicationId) {
        return jobApplicationRepository.findById(applicationId);
    }

    public JobApplication updateApplicationStatus(Long applicationId, ApplicationStatus status) {
        return jobApplicationRepository.findById(applicationId).map(application -> {
            application.setStatusApply(status);
            return jobApplicationRepository.save(application);
        }).orElse(null);
    }
}
