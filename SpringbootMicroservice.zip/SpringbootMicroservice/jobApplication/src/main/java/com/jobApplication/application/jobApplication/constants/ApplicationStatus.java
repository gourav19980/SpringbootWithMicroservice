package com.jobApplication.application.jobApplication.constants;

public enum ApplicationStatus {
    SUCCESS, PENDING, REJECTED
}