package com.jobSeeker.application.jobSeekerApplication.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jobSeeker.application.jobSeekerApplication.model.JobSeeker;
import com.jobSeeker.application.jobSeekerApplication.service.JobSeekerService;

@RestController
@RequestMapping("/jobseeker")
public class JobSeekerController {
    @Autowired
    private JobSeekerService jobSeekerService;

    @PostMapping("/post")
    public JobSeeker postJobSeeker(@RequestBody JobSeeker jobSeeker) {
        return jobSeekerService.saveJobSeeker(jobSeeker);
    }

    @PutMapping("/update/{userId}")
    public JobSeeker updateJobSeeker(@PathVariable Long userId, @RequestBody JobSeeker jobSeeker) {
        return jobSeekerService.updateJobSeeker(userId, jobSeeker);
    }

    @GetMapping("/view/{userId}")
    public Optional<JobSeeker> viewJobSeeker(@PathVariable Long userId) {
        return jobSeekerService.getJobSeekerById(userId);
    }
}
