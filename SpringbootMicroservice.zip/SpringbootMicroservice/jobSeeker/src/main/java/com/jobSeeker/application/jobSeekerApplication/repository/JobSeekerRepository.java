package com.jobSeeker.application.jobSeekerApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jobSeeker.application.jobSeekerApplication.model.JobSeeker;

public interface JobSeekerRepository extends JpaRepository<JobSeeker, Long> {}