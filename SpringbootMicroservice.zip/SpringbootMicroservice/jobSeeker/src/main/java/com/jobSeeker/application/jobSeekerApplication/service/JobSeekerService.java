package com.jobSeeker.application.jobSeekerApplication.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobSeeker.application.jobSeekerApplication.model.JobSeeker;
import com.jobSeeker.application.jobSeekerApplication.repository.JobSeekerRepository;

@Service
public class JobSeekerService {
    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    public JobSeeker saveJobSeeker(JobSeeker jobSeeker) {
        return jobSeekerRepository.save(jobSeeker);
    }

    public JobSeeker updateJobSeeker(Long userId, JobSeeker updatedJobSeeker) {
        return jobSeekerRepository.findById(userId).map(jobSeeker -> {
            jobSeeker.setName(updatedJobSeeker.getName());
            jobSeeker.setSkill(updatedJobSeeker.getSkill());
            jobSeeker.setExperience(updatedJobSeeker.getExperience());
            jobSeeker.setBioData(updatedJobSeeker.getBioData());
            return jobSeekerRepository.save(jobSeeker);
        }).orElse(null);
    }

    public Optional<JobSeeker> getJobSeekerById(Long userId) {
        return jobSeekerRepository.findById(userId);
    }
}
