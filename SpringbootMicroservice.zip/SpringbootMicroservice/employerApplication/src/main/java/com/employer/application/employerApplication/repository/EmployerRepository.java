package com.employer.application.employerApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employer.application.employerApplication.model.Employer;

public interface EmployerRepository extends JpaRepository<Employer, Long> {}