package com.employer.application.employerApplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employer.application.employerApplication.model.Employer;
import com.employer.application.employerApplication.repository.EmployerRepository;

@Service
public class EmployerService {
    @Autowired
    private EmployerRepository employerRepository;

    public Employer registerEmployer(Employer employer) {
        return employerRepository.save(employer);
    }
}