package com.employer.application.employerApplication.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employer.application.employerApplication.model.Employer;
import com.employer.application.employerApplication.service.EmployerService;

@RestController
@RequestMapping("/employer")
public class EmployerController {
    @Autowired
    private EmployerService employerService;
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @PostMapping("/register")
    public Employer registerEmployer(@RequestBody Employer employer) {
        return employerService.registerEmployer(employer);
    }

    @PostMapping("/postJob")
    public String postJob(@RequestBody Map<String, String> jobDetails) {
        kafkaTemplate.send("job-postings", jobDetails.toString());
        return "Job posted successfully";
    }
    
    @PutMapping("/update/postJob")
    public String updateAndPostJob(@RequestBody Map<String, String> jobDetails) {
        // Simulating update process (business logic can be enhanced as needed)
        jobDetails.put("status", "updated");
        kafkaTemplate.send("job-postings", jobDetails.toString());
        return "Job updated and posted successfully";
    }
}
