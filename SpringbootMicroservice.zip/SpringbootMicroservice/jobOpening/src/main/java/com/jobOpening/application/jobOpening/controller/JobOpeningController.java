package com.jobOpening.application.jobOpening.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jobOpening.application.jobOpening.model.JobOpening;
import com.jobOpening.application.jobOpening.service.JobOpeningService;

@RestController
@RequestMapping("/jobopening")
public class JobOpeningController {
    @Autowired
    private JobOpeningService jobOpeningService;

    @PostMapping("/post")
    public JobOpening postJob(@RequestBody JobOpening jobOpening) {
        return jobOpeningService.postJob(jobOpening);
    }

    @GetMapping("/viewbycompany/{companyId}")
    public List<JobOpening> viewByCompany(@PathVariable Long companyId) {
        return jobOpeningService.getJobsByCompany(companyId);
    }

    @GetMapping("/viewbyrole/{role}")
    public List<JobOpening> viewByRole(@PathVariable String role) {
        return jobOpeningService.getJobsByRole(role);
    }

    @GetMapping("/viewbydateofpost/{dateReleased}")
    public List<JobOpening> viewByDate(@PathVariable String dateReleased) {
        return jobOpeningService.getJobsByDate(dateReleased);
    }

    @GetMapping("/viewbyroleandskill")
    public List<JobOpening> viewByRoleAndSkill(@RequestParam String role, @RequestParam String skill) {
        return jobOpeningService.getJobsByRoleAndSkill(role, skill);
    }

    @DeleteMapping("/deleteJob/{jobId}")
    public void deleteJob(@PathVariable Long jobId, @RequestParam String role) {
        jobOpeningService.deleteJob(jobId, role);
    }
}

