package com.jobOpening.application.jobOpening.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobOpening.application.jobOpening.model.JobOpening;
import com.jobOpening.application.jobOpening.repository.JobOpeningRepository;

@Service
public class JobOpeningService {
    @Autowired
    private JobOpeningRepository jobOpeningRepository;

    public JobOpening postJob(JobOpening jobOpening) {
        return jobOpeningRepository.save(jobOpening);
    }

    public List<JobOpening> getJobsByCompany(Long companyId) {
        return jobOpeningRepository.findByCompanyId(companyId);
    }

    public List<JobOpening> getJobsByRole(String role) {
        return jobOpeningRepository.findByRole(role);
    }

    public List<JobOpening> getJobsByDate(String dateReleased) {
        return jobOpeningRepository.findByDateReleased(dateReleased);
    }

    public List<JobOpening> getJobsByRoleAndSkill(String role, String skill) {
        return jobOpeningRepository.findByRoleAndSkill(role, skill);
    }

    public void deleteJob(Long jobId, String role) {
        if (!"EMPLOYER".equalsIgnoreCase(role)) {
            throw new RuntimeException("Only employers can delete jobs");
        }
        jobOpeningRepository.deleteById(jobId);
    }
}
