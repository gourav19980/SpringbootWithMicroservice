package com.jobOpening.application.jobOpening.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jobOpening.application.jobOpening.model.JobOpening;

public interface JobOpeningRepository extends JpaRepository<JobOpening, Long> {
    List<JobOpening> findByCompanyId(Long companyId);
    List<JobOpening> findByRole(String role);
    List<JobOpening> findByDateReleased(String dateReleased);
    List<JobOpening> findByRoleAndSkill(String role, String skill);
}